export enum ContentType {
    STB = 'stb',
    VODS = 'vod',
    SERIES = 'series',
    ITV = 'itv',
    FAVORITES = 'favorites',
    /* RADIO = 'radio', */
}
