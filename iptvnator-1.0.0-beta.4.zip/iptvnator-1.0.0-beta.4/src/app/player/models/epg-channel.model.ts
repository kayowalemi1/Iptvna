export interface EpgChannel {
    id: string;
    name: string;
    icon: string[];
    url: string[];
}
