export class WhatsNewServiceStub {
    changeDialogVisibleState(): void {}
    getModalsByVersion(): any {
        return [];
    }
}
