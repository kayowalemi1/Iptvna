export interface StalkerFavoriteItem {
    id?: string;
    stream_id?: string;
    movie_id?: string;
    name: string;
    details?: any;
}
