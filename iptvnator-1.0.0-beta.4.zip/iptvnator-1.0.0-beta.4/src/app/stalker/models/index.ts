export * from './stalker-favorite-item.interface';
export * from './stalker-season.interface';
export * from './stalker-serial-details.interface';
export * from './stalker-vod-details.interface';
