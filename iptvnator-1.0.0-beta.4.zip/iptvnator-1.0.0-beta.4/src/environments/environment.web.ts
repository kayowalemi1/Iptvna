export const AppConfig = {
    production: false,
    environment: 'WEB',
    version: require('../../package.json').version,
    BACKEND_URL: 'http://localhost:3333',
};
